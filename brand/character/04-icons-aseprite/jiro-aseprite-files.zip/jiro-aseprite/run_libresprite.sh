#!/bin/bash
export XDG_RUNTIME_DIR=/tmp/xdg SDL_VIDEODRIVER=dummy SDL_AUDIODRIVER=dummy
LS=/tmp/jiro/ls/squashfs-root/AppRun
IN=/tmp/jiro/ase/in; OUT=/tmp/jiro/serve/ase; mkdir -p $OUT
for f in $IN/icon-clean-*.png; do
  name=$(basename "$f" .png)
  cat > /tmp/jiro/ase/despeckle-$name.js <<JS
var d = app.open("$f");
var img = d.sprite.layer(0).cel(0).image;
var w = img.width, h = img.height, src = [], changed = 0;
for (var y = 0; y < h; ++y) { src[y] = []; for (var x = 0; x < w; ++x) src[y][x] = img.getPixel(x, y); }
for (var y = 1; y < h - 1; ++y) for (var x = 1; x < w - 1; ++x) {
  var v = src[y][x], counts = {}, same = 0, best = -1, bestN = 0;
  for (var dy = -1; dy <= 1; ++dy) for (var dx = -1; dx <= 1; ++dx) {
    if (!dx && !dy) continue; var n = src[y + dy][x + dx];
    if (n === v) same++; else { counts[n] = (counts[n] || 0) + 1; if (counts[n] > bestN) { bestN = counts[n]; best = n; } }
  }
  if (same === 0 && bestN >= 5) { img.putPixel(x, y, best); changed++; }
}
console.log("$name: despeckled " + changed + " isolated pixels of " + (w * h));
JS
  $LS -b --script /tmp/jiro/ase/despeckle-$name.js --save-as $OUT/$name.ase 2>&1 | grep "despeckled"
  size=$(echo $name | grep -o '[0-9]\+' | head -1); scale=$((768 / size))
  $LS -b $OUT/$name.ase --save-as $OUT/$name-1x.png >/dev/null 2>&1
  $LS -b $OUT/$name.ase --scale $scale --save-as $OUT/$name-${scale}x.png >/dev/null 2>&1
done
# sprite sheet of the 128px icon variants
ls $OUT
