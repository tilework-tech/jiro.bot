from PIL import Image
import numpy as np, os

SRC = Image.open('/tmp/jiro/original.png').convert('RGB')
FORCED = [(91, 159, 201), (170, 215, 240), (253, 254, 249), (30, 20, 16)]
OUT = '/tmp/jiro/ase/in'; os.makedirs(OUT, exist_ok=True)

def build_palette(img, n, focus_box, forced):
    fx0, fy0, fx1, fy1 = [int(v * s) for v, s in zip(focus_box, (img.width, img.height) * 2)]
    q = img.crop((fx0, fy0, fx1, fy1)).quantize(colors=n - len(forced), method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    pal = q.getpalette()[: 3 * (n - len(forced))]
    cols = [tuple(pal[i:i + 3]) for i in range(0, len(pal), 3)] + forced
    pimg = Image.new('P', (1, 1)); flat = [c for col in cols for c in col]
    pimg.putpalette(flat + [0] * (768 - len(flat)))
    return pimg

def vignette(img, cx, cy, rx, ry, inner, floor):
    a = np.asarray(img).astype(np.float32); h, w = a.shape[:2]
    ys, xs = np.mgrid[0:h, 0:w]
    d = np.sqrt(((xs / w - cx) / rx) ** 2 + ((ys / h - cy) / ry) ** 2)
    f = floor + (1 - floor) * np.clip(1 - (d - inner) / (1.7 - inner), 0, 1)
    return Image.fromarray(np.clip(a * f[..., None], 0, 255).astype(np.uint8))

icon_src = SRC.crop((110, 0, 470, 360))
for size in (96, 128):
    small = icon_src.resize((size, size), Image.BOX)
    variants = {
        'icon': vignette(small, 0.44, 0.5, 0.42, 0.62, 0.85, 0.30),
        'icon-dark': vignette(small, 0.44, 0.5, 0.36, 0.55, 0.70, 0.06),
    }
    for name, img in variants.items():
        pimg = build_palette(img, 28, (0.2, 0.05, 0.85, 0.95), FORCED)
        q = img.quantize(palette=pimg, dither=Image.Dither.NONE)
        q.save(f'{OUT}/{name}-{size}.png')
        q.transpose(Image.FLIP_LEFT_RIGHT).save(f'{OUT}/{name}-{size}-mirror.png')
small = SRC.resize((128, 128), Image.BOX)
img = vignette(small, 0.4, 0.55, 0.6, 0.8, 0.95, 0.45)
pimg = build_palette(img, 32, (0.05, 0.05, 0.75, 0.95), FORCED)
img.quantize(palette=pimg, dither=Image.Dither.NONE).save(f'{OUT}/scene-128.png')
print('prepared', sorted(os.listdir(OUT)))
