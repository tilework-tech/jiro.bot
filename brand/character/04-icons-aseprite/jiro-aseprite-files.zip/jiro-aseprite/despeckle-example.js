var d = app.open("/tmp/jiro/ase/in/icon-128.png");
var img = d.sprite.layer(0).cel(0).image;
var w = img.width, h = img.height, src = [], changed = 0;
for (var y = 0; y < h; ++y) { src[y] = []; for (var x = 0; x < w; ++x) src[y][x] = img.getPixel(x, y); }
for (var y = 1; y < h - 1; ++y) for (var x = 1; x < w - 1; ++x) {
  var v = src[y][x], counts = {}, same = 0, best = -1, bestN = 0;
  for (var dy = -1; dy <= 1; ++dy) for (var dx = -1; dx <= 1; ++dx) {
    if (!dx && !dy) continue; var n = src[y + dy][x + dx];
    if (n === v) same++; else { counts[n] = (counts[n] || 0) + 1; if (counts[n] > bestN) { bestN = counts[n]; best = n; } }
  }
  if (same === 0 && bestN >= 5) { img.putPixel(x, y, best); changed++; }
}
console.log("icon-128: despeckled " + changed + " isolated pixels of " + (w * h));
